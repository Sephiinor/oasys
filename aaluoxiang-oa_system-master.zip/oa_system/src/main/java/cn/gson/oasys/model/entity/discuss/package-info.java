/**
 * 
 */
/**
 * @author admin
 *
 */
package cn.gson.oasys.model.entity.discuss;