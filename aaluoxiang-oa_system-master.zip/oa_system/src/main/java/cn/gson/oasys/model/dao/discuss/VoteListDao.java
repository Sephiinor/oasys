package cn.gson.oasys.model.dao.discuss;

import org.springframework.data.jpa.repository.JpaRepository;

import cn.gson.oasys.model.entity.discuss.VoteList;

public interface VoteListDao extends JpaRepository<VoteList, Long>{

}
